# github-codedeploy-ec2-cicd
This pipeline is to update my wordpress website
testing with rance 2/16
